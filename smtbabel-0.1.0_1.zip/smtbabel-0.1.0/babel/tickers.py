from babel_assets import TICKERVERSE
from collections import Counter


def _tickers(cnames=None, filter_vals=None):
    if not cnames and not filter_vals:
        return list(TICKERVERSE['TICKER'].values)

    if cnames and filter_vals:
        df = TICKERVERSE.copy(deep=True)

        for cname, fv in zip(cnames, filter_vals):
            if isinstance(fv, list):
                df = df[df[cname] in fv]
            else:
                df = df[df[cname] == fv]

        return list(df['TICKER'].values)


def dups() -> Counter:
    c_1, c_2 = Counter(), Counter()

    for t in _tickers():
        c_1[t] += 1

    for t in _tickers():
        if c_1[t] > 1:
            c_2[t] = c_1[t]

    return c_2


def all():
    return _tickers()


def mandated():
    return _tickers(['IS_MANDATED'], [True])


def new():
    return _tickers(['IN_DB'], [False])


def ohlc():
    return _tickers(['BarType'], ["OHLC"])


def ohlcv():
    return _tickers(['BarType'], ["OHLCV"])


def uses_ohlc(ticker):
    return ticker in ohlc()


def spot():
    return _tickers(['Type', 'SUBTYPE1', 'SUBTYPE2'],
                    ['MACRO', 'FXOUTRIGHT', 'SPOT']
                    )


def etfs():
    return _tickers(['Type', 'SubType1'], ['EQUITY', 'ETF'])


def uses_pct(ticker):
    return ticker in _tickers(['USE_PCT'], [True])


def uses_net(ticker):
    return ticker in _tickers(['USE_PCT'], [False])


def is_outright(ticker):
    return ticker in _tickers(['SUBTYPE1'], ['FXOUTRIGHT'])


def is_g10(ticker):
    return ticker in _tickers(['REGIONS'], ['G10::G10'])


def ticker_refdata(ticker):
    return TICKERVERSE[TICKERVERSE['TICKER'] == ticker]. \
        tail(n=1). \
        to_dict('records')[-1]
