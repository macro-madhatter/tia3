=======
History
=======

0.1.0 (2020-07-03)
------------------

* First release on PyPI.
