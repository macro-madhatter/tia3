import tia3.analysis.perf
from tia3.analysis.model import *