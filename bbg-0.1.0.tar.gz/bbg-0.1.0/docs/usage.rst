=====
Usage
=====

To use bbg in a project::

    import bbg
