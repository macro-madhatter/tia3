"""Top-level package for homer."""

__author__ = """Abhay Nainan"""
__email__ = 'macro.madhatter@gmail.com'
__version__ = '0.1.0'
