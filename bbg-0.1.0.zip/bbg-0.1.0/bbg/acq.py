"""
Data acquistion API - wrapper over tia to ease dataframe retrieval
"""

import datetime as dt

import pandas as pd
import tia3.bbg.datamgr as dm
from tia3.bbg import LocalTerminal
from homer.base import OHLC_FIELDS, OHLCV_FIELDS, BBGTicker, BBGFieldList, FieldMapper, BBGTickerList
from homer.validation import flatten_multi_index
import collections
import functools

INTERVAL_PERCENT_CHANGE: str = "INTERVAL_PERCENT_CHANGE"
INTERVAL_NET_CHANGE: str = "INTERVAL_NET_CHANGE"
START_DATE_OVERRIDE: str = "START_DATE_OVERRIDE="
END_DATE_OVERRIDE: str = "END_DATE_OVERRIDE="

MGR: dm.BbgDataManager = dm.BbgDataManager()


def _map_colnames(df: pd.DataFrame) -> pd.DataFrame:
    df.columns = [FieldMapper[cname] for cname in list(df)]
    return df


def validate_df(df_func):
    def wrapper(*args, **kwargs):
        df: pd.DataFrame = df_func(*args, **kwargs)
        if df.empty:
            raise ValueError("Received Empty Dataframe")
        if not isinstance(df.index, pd.DatetimeIndex):
            raise TypeError("Expected datetimeindex, received: {}".format(type(df.index)))
        df.pipe(flatten_multi_index) \
            .pipe(_map_colnames)
        return df

    return wrapper


@validate_df
def _historical_df(ticker: BBGTicker, fields: BBGFieldList, st: dt.date, end: dt.date) -> pd.DataFrame:
    return MGR[ticker].get_historical(fields, st, end)


@functools.lru_cache(maxsize=128)
def ohlc(ticker: BBGTicker, st: dt.date, end: dt.date) -> pd.DataFrame:
    return _historical_df(ticker, [f.value for f in OHLC_FIELDS], st, end)


@functools.lru_cache(maxsize=128)
def ohlcv(ticker: BBGTicker, st: dt.date, end: dt.date) -> pd.DataFrame:
    return _historical_df(ticker, [f.value for f in OHLCV_FIELDS], st, end)


def last(ticker: BBGTicker):
    return MGR[ticker].PX_LAST


def last_mult(tickers, asdict=True):
    resp = LocalTerminal.get_reference_data(tickers, ['PX_LAST'], ignore_field_error=1)

    if asdict:
        resp = resp.as_map()
        return {k: v['PX_LAST'] for k, v in resp.items()}

    else:
        return resp.as_frame()


def _reference_data(ticker: BBGTicker, fld: str, *args, **kwargs):
    return LocalTerminal.get_reference_data(ticker, fld, *args, **kwargs)


def interval_change(ticker: BBGTicker, st: dt.date, end: dt.date, as_pct: bool = True) -> float:
    fld = INTERVAL_PERCENT_CHANGE if as_pct else INTERVAL_NET_CHANGE

    st_str, end_str = st.strftime('%Y%m%d'), end.strftime('%Y%m%d')

    r = _reference_data(ticker, fld, START_DATE_OVERRIDE=st_str, END_DATE_OVERRIDE=end_str)

    d: collections.defaultdict = r.as_map()

    return d[ticker][fld]
