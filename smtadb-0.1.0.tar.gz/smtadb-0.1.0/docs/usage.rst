=====
Usage
=====

To use adb in a project::

    import adb
