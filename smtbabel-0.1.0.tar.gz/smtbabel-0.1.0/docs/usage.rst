=====
Usage
=====

To use babel in a project::

    import babel
