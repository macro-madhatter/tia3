"""
Currency related reference data functions + utils
"""
import assets
import pytest

ORDERED_CCYS = list(assets.CCYVERSE['CCY'].values)

FWD_CODE = {k: v for k, v in
            zip(list(assets.CCYVERSE['CCY'].values),
                list(assets.CCYVERSE['FWD'].values))
            }


def rank(ccy):
    return ORDERED_CCYS.index(ccy)


def cmp(ccy1, ccy2):
    return rank(ccy1) < rank(ccy2)


def to_base(ccy: str, base: str = "USD", as_ticker: bool = True):
    ccypair = base + ccy if cmp(base, ccy) else ccy + base

    if as_ticker:
        return ccypair + " CURNCY"
    else:
        return ccypair


def split_ccypair(ccypair):
    return ccypair[:3], ccypair[3:6]


def is_cross(ccypair: str, base: str = "USD"):
    """
    Check if ABCXYZ is a cross
    :param ccypair: str AUDINR CURNCY
    :param base: str USD
    :return: bool True
    """
    ccy1, ccy2 = split_ccypair(ccypair)
    return ccy1 != base and ccy2 != base


def bases_from_cross(cross, base='USD'):
    """
    Split cross ccypair into 2 base ccypairs
    :param base: base ccy to split the cross against
    :param cross: Cross ex. AUDINR CURNCY
    :return: AUDUSD CURNCY, USDINR CURNCY
    """
    cross = cross[:6]  # AUDINR CURNCY --> AUDINR
    ccy1, ccy2 = split_ccypair(cross)

    if ccy1 == ccy2:
        err = "CCY1:{} and CCY2:{} cannot be the same"
        raise ValueError(err.format(ccy1, ccy2))

    if base in [ccy1, ccy2]:
        err = "Base currency: {} already present in cross: {}"
        raise ValueError(err.format(base, cross))

    return to_base(ccy1, base), to_base(ccy2, base)


def base_trades_from_cross(cross, signal, base: str = "USD"):
    ccy1, ccy2 = split_ccypair(cross)
    pair1, pair2 = bases_from_cross(cross, base)

    return {
        pair1: signal if ccy1 == pair1[:3] else -signal,
        pair2: -signal if ccy2 == pair2[:3] else signal
    }


def test_split_cross():
    assert bases_from_cross("AUDINR CURNCY") == \
           ("AUDUSD CURNCY", "USDINR CURNCY")

    assert bases_from_cross("AUDINR CURNCY", "EUR") == \
           ("EURAUD CURNCY", "EURINR CURNCY")

    with pytest.raises(ValueError):
        bases_from_cross("AUDAUD CURNCY", "EUR")

    with pytest.raises(ValueError):
        bases_from_cross("AUDUSD CURNCY")

    assert bases_from_cross("AUDUSD CURNCY", "EUR") == \
           ("EURAUD CURNCY", "EURUSD CURNCY")


def test_split_cross_signal():
    assert base_trades_from_cross("AUDINR CURNCY", -1) == {
        "AUDUSD CURNCY": -1,
        "USDINR CURNCY": -1,
    }

    assert base_trades_from_cross("AUDINR CURNCY", -1, "EUR") == {
        "EURAUD CURNCY": 1,
        "EURINR CURNCY": -1,
    }

    assert base_trades_from_cross("EURCAD CURNCY", 1, "USD") == {
        "EURUSD CURNCY": 1,
        "USDCAD CURNCY": 1,
    }


def test_is_cross():
    assert not is_cross("EURUSD")
    assert is_cross("EURCAD")
    assert not is_cross("EURCAD", base="EUR")
