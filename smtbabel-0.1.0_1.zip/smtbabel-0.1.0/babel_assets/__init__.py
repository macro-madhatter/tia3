import pathlib
import pandas as pd

ASSETS = pathlib.Path(__file__).parents[1] / "babel_assets"
SPLASH = ASSETS / "ascii_art.txt"
TICKERVERSE = pd.read_csv(ASSETS / "Tickerverse.csv")
CCYVERSE = pd.read_csv(ASSETS / "CCYVerse.csv")


def splash():
    with open(SPLASH, 'r') as f:
        splash_txt: str = f.read()

    return splash_txt
