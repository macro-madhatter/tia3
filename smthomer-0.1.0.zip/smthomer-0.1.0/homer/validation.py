import pandas as pd
import numpy as np
import datetime as dt
from dateutil.relativedelta import relativedelta
from typing import Tuple
from homer.base import *


def flatten_multi_index(df: pd.DataFrame) -> pd.DataFrame:
    df.columns = df.columns.get_level_values(0)
    return df


def _validate_index(df: pd.DataFrame) -> None:
    if not isinstance(df.index, pd.DatetimeIndex):
        err: str = "Expected datetimeindex, received: {}".format(type(df.index))
        raise TypeError(err)


def _validate_ohlc_colnames(df: pd.DataFrame):
    return set(df.columns).issubset(set(list(FieldMapper.items())))


def _validator_fn_group(df: pd.DataFrame) -> None:
    """ Simple group of independent validation functions to reduce cpy/paste of code"""
    _validate_index(df)
    _validate_ohlc_colnames(df)


def check_high_low_inversion(df: pd.DataFrame) -> np.array:
    """
    Flag where low >= high
    :param df: input dataframe
    :return: pd.Series with index-values where highs <= lows
    """
    _validator_fn_group(df)
    return df.where(df["low"] >= df["high"]).dropna(inplace=True)


def _check_ts_spike(s1: pd.Series, s2: pd.Series, thresh: float, thresh_as_pcnt: bool = True):
    """ Base function to check s2-s1 crosses pcnt/abs threshold"""
    res: pd.Series
    if thresh_as_pcnt:
        res = s1.where((s2 - s1) / s1.abs() > (thresh / 100))
    else:
        res = s1.where(s2 - s1 > thresh)

    res.dropna(inplace=True)
    return res.index.values


def check_intraday_spike(df: pd.DataFrame, thresh: float, thresh_as_pcnt: bool = True):
    """ Flag where intraday total px change exceeds thresh """
    _validator_fn_group(df)
    return _check_ts_spike(df["low"], df["high"], thresh, thresh_as_pcnt)


def check_nextday_spike(df: pd.DataFrame, thresh: float, thresh_as_pcnt: bool = True):
    """ Flag where next-day open - today close exceeds thresh"""
    _validator_fn_group(df)
    today_close: pd.Series = df["close"][:-1]
    tomm_open: pd.Series = df["open"].shift(-1)
    return _check_ts_spike(tomm_open, today_close, thresh, thresh_as_pcnt)


DateGapList = [Tuple[dt.date, dt.date]]


@np.vectorize
def dt64_to_date(dt64) -> dt.date:
    """Converts np dt64 types to dt.date. Used on ndarrays after vectorization"""
    return pd.to_datetime(dt64).date()


def check_date_gap(df: pd.DataFrame, thresh: int = 3) -> DateGapList:
    """ Check whether time-series has date gaps > threshold number of days"""
    _validate_index(df)

    # noinspection PyTypeChecker
    idx_dates: np.ndarray = dt64_to_date(df.index.values)

    tdy: np.ndarray = idx_dates[:-1]  # map dt64 objects to datetime.date objects
    tom: np.ndarray = idx_dates[1:]
    thresh_delta: relativedelta = relativedelta(days=thresh)
    return [(tdy[i], tom[i]) for i in range(len(tdy)) if tdy[i] + thresh_delta < tom[i]]
