from typing import List, Dict
from enum import Enum, auto
import numpy as np


# noinspection PyMethodParameters
class AutoName(Enum):
    def _generate_next_value_(name, start, count, last_values):
        return name


class PxType(AutoName):
    BID = auto()
    ASK = auto()
    MID = auto()


class VolProducts(AutoName):
    CALL = auto()
    PUT = auto()
    STRADDLE = auto()
    STRANGLE = auto()
    FLY = auto()


class BBGField(AutoName):
    PX_OPEN = auto()
    PX_HIGH = auto()
    PX_LOW = auto()
    PX_LAST = auto()
    VOLUME = auto()


BBGTicker = str
BBGTickerList = List[BBGTicker]
Ccy = str
BBGFieldList = List[BBGField]
Basket = List[BBGTicker]

OHLC_FIELDS = [BBGField.PX_LOW,
               BBGField.PX_HIGH,
               BBGField.PX_OPEN,
               BBGField.PX_LAST
               ]

OHLCV_FIELDS = [BBGField.PX_LOW,
                BBGField.PX_HIGH,
                BBGField.PX_OPEN,
                BBGField.PX_LAST,
                BBGField.VOLUME
                ]

FieldMapper: Dict[str, str] = {
    "Date": "date",
    "PX_OPEN": "open",
    "PX_HIGH": "high",
    "PX_LOW": "low",
    "PX_LAST": "close",
    "VOLUME": "volume"
}


# noinspection PyMethodParameters
class AutoNameTenorDelta(Enum):
    def _generate_next_value_(name, start, count, last_values):
        return name[1:] + name[0]


class Delta(AutoNameTenorDelta):
    D5 = auto()
    D10 = auto()
    D15 = auto()
    D25 = auto()
    D50 = auto()


class Tenor(AutoNameTenorDelta):
    W1 = auto()
    M1 = auto()
    M3 = auto()
    M6 = auto()
    M9 = auto()
    M12 = auto()


FX_SWAP_LEGS = [
    (Tenor.W1, Tenor.M1),

    (Tenor.M1, Tenor.M3),
    (Tenor.M1, Tenor.M6),
    (Tenor.M1, Tenor.M9),
    (Tenor.M1, Tenor.M12),

    (Tenor.M3, Tenor.M6),
    (Tenor.M3, Tenor.M9),
    (Tenor.M3, Tenor.M12),

    (Tenor.M6, Tenor.M9),
    (Tenor.M6, Tenor.M12),

    (Tenor.M9, Tenor.M12)
]


def tenors_str():
    return [t.value for t in Tenor]


class FwdPxType(AutoName):
    POINTS = auto()
    OUTRIGHT = auto()


def call_put_for_delta(rr, fly, atm):
    mat_a = np.array([[1, -1], [1, 1]])
    mat_b = np.array([rr, 2 * (fly + atm)])
    c = np.linalg.solve(mat_a, mat_b)
    return c[0], c[1]
