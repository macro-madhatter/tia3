from homer.base import BBGTicker
import datetime as dt
import pprint
import pandas as pd
from typing import List
from arctic import Arctic, CHUNK_STORE

OUTDATED_DAYS_THRESH: int = 5


ArcticSymbol = str

a = Arctic('localhost')
a.initialize_library('SMT', lib_type=CHUNK_STORE)
lib = a['SMT']


def write_symbol(symbol, df: pd.DataFrame, **kwargs):
    lib.write(symbol=symbol, item=df, **kwargs)


def update_symbol(symbol, df: pd.DataFrame, upsert=True, **kwargs):
    lib.update(symbol=symbol, item=df, upsert=upsert, **kwargs)


def read_symbol(symbol, st=None, end=None, **kwargs) -> pd.DataFrame:
    if not any((st, end)):
        return lib.read(symbol, **kwargs)
    elif isinstance(st, dt.date) and not isinstance(end, dt.date):
        return lib.read(symbol, pd.date_range(st, dt.date.today()), **kwargs)
    elif isinstance(st, dt.date) and isinstance(end, dt.date):
        return lib.read(symbol, pd.date_range(st, end, **kwargs))
    else:
        raise ValueError("Errors with parsing st || end dts")


def read_symbol_on_dt(symbol, some_dt: dt.date, asdict: bool = True):
    df: pd.DataFrame = read_symbol(symbol, st=some_dt, end=some_dt)
    assert len(df) == 1
    return df.to_dict('records')[-1] if asdict else df


def list_symbols() -> List[str]:
    return lib.list_symbols()


def _all_symbols_to_upper() -> None:
    for s in list_symbols():
        if not (s == s.upper()):
            print(s)
            lib.rename(s, s.upper())


def possible_outdated_symbols() -> List[BBGTicker]:
    outdated = {}

    for ticker in list_symbols():
        print(ticker)

        df: pd.DataFrame = read_symbol(ticker, st=dt.date.today() - dt.timedelta(days=OUTDATED_DAYS_THRESH))

        if df.empty:
            outdated[ticker] = False
        else:
            last_dt: dt.date = pd.to_datetime(df.tail(n=1).index.values[0]).date()
            print(last_dt)
            days_since_update = (dt.date.today() - last_dt).days
            print(days_since_update)
            if days_since_update > OUTDATED_DAYS_THRESH:
                outdated[ticker] = last_dt

    pprint.pprint(outdated)
    return list(outdated.keys())
