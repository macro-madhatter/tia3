# Monkey patch module
import tia3.rlab.patch

from tia3.rlab.components import *
from tia3.rlab.table import *
from tia3.rlab.builder import *
from tia3.rlab.font import *

