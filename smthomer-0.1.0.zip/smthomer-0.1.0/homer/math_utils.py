import collections
import datetime as dt
import functools
import typing

import numpy as np
import pandas as pd
from statsmodels.stats.diagnostic import acorr_ljungbox
from statsmodels.tsa.stattools import adfuller


def check_one_dimension(ndarray_input_func):
    """
    Decorator raising ValueError if input ndarray is not of one dimension

    Returns arrays should only have one dimension. Since several NumPy functions
    silently return N-1 dimensional statistical measures of N-dimensional
    arrays, it is important to validate the ndarray before performing expensive
    computation.

    An alternative would be to use pd.Series which guarantees one dimensional
    data. However the cost of indexing a pd.Series objects is far higher than
    that of a np.ndarray object, hence it is worth error checking

    Parameters
    -----------
        ndarray_input_func:
            Any function that accepts ndarrays, but needs only 1D ndarrays
            argument
    Returns
    ---------
        _wrapper:
            Same as the argument ndarray_input_func in case
    """

    @functools.wraps(ndarray_input_func)
    def _wrapper(*args, **kwargs):
        arr_dimensions: int = 0
        if 'returns_arr' in kwargs:
            arr_dimensions = kwargs['returns_arr'].ndim
        elif isinstance(args[0], np.ndarray):
            arr_dimensions = args[0].ndim
        if arr_dimensions != 1:
            raise ValueError(
                "Expected 1 Dimension, got {}".format(arr_dimensions))
        else:
            return ndarray_input_func(*args, **kwargs)

    return _wrapper


def num_losses(returns_arr: np.ndarray, threshold: float) -> int:
    """
    Counts the number of losses in the returns array

    Counts the number of returns that fall below the loss threshold

    Parameters
    ----------
    returns_arr : array like
        Array with absolute returns
    threshold : float
        Cut-off to determine classification as upside/downside

    Returns
    -------
    num_losses : int
        Number of returns below the loss threshold
    """
    num_dims: int = returns_arr.ndim
    assert num_dims == 1, "Require 1D array received {}".format(num_dims)
    # noinspection PyTypeChecker
    return len(np.where(returns_arr < -threshold)[0])


def num_gains(returns_arr: np.ndarray, threshold: float) -> int:
    """
    Counts the number of gains in the returns array

    Counts the number of returns that fall below the gains threshold

    Parameters
    ----------
    returns_arr : array like
        Array with absolute returns
    threshold : float
        Cut-off to determine classification as upside/downside

    Returns
    -------
    num_gains : int
        Number of returns above the gains threshold
    """
    num_dims: int = returns_arr.ndim
    assert num_dims == 1, "Require 1D array received {}".format(num_dims)
    # noinspection PyTypeChecker
    return len(np.where(returns_arr > threshold)[0])


def partial_arr(returns_arr: np.ndarray, downside: bool,
                threshold: float) -> np.ndarray:
    """
    Helper function to compute partial moments of the array

    Include only the array values that fall above or below a specific threshold
    Set all other values to zero

    Parameters
    ----------
    returns_arr : array like
        Array with absolute returns
    downside : bool
        If True, return downside partial, else return upside partial
    threshold : float
        Cut-off to determine classification as upside/downside

    Returns
    -------
    clipped_array : ndarray
        An array with the returns of `a`, but where values
        above(below)the threshold are replaced with zero
    """
    # create array copy to prevent inadvertent modifications to source array
    num_dims: int = returns_arr.ndim
    assert num_dims == 1, "Require 1D array received {}".format(num_dims)
    # noinspection PyTypeChecker
    arr = np.array(returns_arr)
    # subtract the threshold and perform clipping
    # implement r_i - r_thresh
    arr -= threshold
    if downside:
        # implement min(r_i - r_thresh, 0)
        return np.clip(arr, a_min=None, a_max=0)
    else:
        # implement max(r_i - r_thresh, 0)
        return np.clip(arr, a_min=0, a_max=None)


def partial_statistic(returns_arr: np.ndarray, func, downside: bool,
                      threshold: float) -> float:
    """
    Computes statistic on partial array using user-defined function

    Parameters
    ----------
    returns_arr : array like
        Array with absolute returns
    func :
        User-defined function using partial array as argument to compute value

    downside : bool
        If True, return downside partial, else return downside partial
    threshold : float
        Cut-off to determine classification as upside/downside

    Returns
    -------
    statistic : float
        Value of partial statistic computed by func
    """
    num_dims: int = returns_arr.ndim
    assert num_dims == 1, "Require 1D array received {}".format(num_dims)
    # noinspection PyTypeChecker
    partial_returns = partial_arr(returns_arr, downside, threshold)
    return func(partial_returns)


def upside_risk(returns_arr: np.ndarray, threshold: float) -> float:
    """
        Volatility of returns that exceed a given target

        Parameters
        ----------
        returns_arr : array like
            Array with absolute returns
        threshold : float
            Cut-off to determine classification as upside/downside

        Returns
        -------
        upside_risk : float
             Standard deviation of the partial array above the threshold

        """
    num_dims: int = returns_arr.ndim
    assert num_dims == 1, "Require 1D array received {}".format(num_dims)
    # noinspection PyTypeChecker
    return partial_statistic(returns_arr, np.std, False, threshold)


def downside_risk(returns_arr: np.ndarray, threshold: float) -> float:
    """
        volatility of underperformance below a minimum target rate

        Parameters
        ----------
        returns_arr : array like
            Array with absolute returns
        threshold : float
            Cut-off to determine classification as upside/downside

        Returns
        -------
        downside_risk : float
            Standard deviation of the partial array below the threshold
        """
    num_dims: int = returns_arr.ndim
    assert num_dims == 1, "Require 1D array received {}".format(num_dims)
    # noinspection PyTypeChecker
    return partial_statistic(returns_arr, np.std, True, threshold)


def upside_semivariance(returns_arr: np.ndarray) -> float:
    """
        volatility of outperformance over mean returns

        Parameters
        ----------
        returns_arr : array like
            Array with absolute returns

        Returns
        -------
        upside_semivariance : float
            Standard deviation of the partial array above the mean returns
        """
    num_dims: int = returns_arr.ndim
    assert num_dims == 1, "Require 1D array received {}".format(num_dims)
    # noinspection PyTypeChecker
    return partial_statistic(returns_arr, np.std, False, np.mean(returns_arr))


def downside_semivariance(returns_arr: np.ndarray) -> float:
    """
        volatility of underperformance below mean returns

        Parameters
        ----------
        returns_arr : array like
            Array with absolute returns


        Returns
        -------
        downside_semivariance : float
            Standard deviation of the partial array below the mean returns
        """
    num_dims: int = returns_arr.ndim
    assert num_dims == 1, "Require 1D array received {}".format(num_dims)
    # noinspection PyTypeChecker
    return partial_statistic(returns_arr, np.std, True, np.mean(returns_arr))


def upside_potential(returns_arr: np.ndarray, threshold: float) -> float:
    """
        average sum of underperformance above mean returns

        Parameters
        ----------
        returns_arr : array like
            Array with absolute returns
        threshold : float
            Cut-off to determine classification as upside/downside

        Returns
        -------
        upside_potential : float
            Mean of the partial array above the threshold
        """
    num_dims: int = returns_arr.ndim
    assert num_dims == 1, "Require 1D array received {}".format(num_dims)
    # noinspection PyTypeChecker
    return partial_statistic(returns_arr, np.mean, False, threshold)


def downside_potential(returns_arr: np.ndarray, threshold: float) -> float:
    """
        average sum of underperformance below mean returns

        Parameters
        ----------
        returns_arr : array like
            Array with absolute returns
        threshold : float
            Cut-off to determine classification as upside/downside

        Returns
        -------
        downside_potential : float
            Mean of the partial array below the threshold
        """
    num_dims: int = returns_arr.ndim
    assert num_dims == 1, "Require 1D array received {}".format(num_dims)
    # noinspection PyTypeChecker
    return partial_statistic(returns_arr, np.mean, True, threshold)


# Performance Ratio:

def omega_ratio(returns_arr: np.ndarray, threshold: float) -> float:
    """

        Gain-loss ratio that implicitly adjusts for skewness and kurtosis.

        Gain-loss ratio that captures the information in
        the higher moments of a return distribution.
        The higher the omega ratio the better

        Parameters
        ----------
        returns_arr : array like
            Array with absolute returns
        threshold : float
            Cut-off to determine classification as upside/downside

        Returns
        -------
        omega_ratio : float

    """
    num_dims: int = returns_arr.ndim
    assert num_dims == 1, "Require 1D array received {}".format(num_dims)
    # noinspection PyTypeChecker
    return abs(upside_potential(returns_arr, threshold) / downside_potential(returns_arr, threshold))


def gain_loss_ratio(returns_arr: np.ndarray) -> float:
    """

        Special case of Omega Ratio with threshold set to zero

        See Also
        --------

        iautils.omega_ratio

    """
    num_dims: int = returns_arr.ndim
    assert num_dims == 1, "Require 1D array received {}".format(num_dims)
    # noinspection PyTypeChecker
    return abs(omega_ratio(returns_arr, 0))


def d_ratio(returns_arr: np.ndarray) -> float:
    """

        Inverse gain-loss ratio weighted by frequency of +ve/-ve returns

        The d ratio will have values between zero and infinity and can be used
        to rank the performance of portfolios. The lower the d ratio the better
        the performance, a value of zero indicating there are no returns less
        than zero and a value of infinity indicating there are no returns
        greater than zero.


        Parameters
        ----------
        returns_arr : array like
            Array with absolute returns

        Returns
        -------
        d_ratio : float
    """

    sum_wins: float = partial_statistic(returns_arr, np.sum, False, 0)
    sum_losses: float = partial_statistic(returns_arr, np.sum, True, 0)
    freq_weighted_sum_wins = sum_wins * num_gains(returns_arr, 0)
    freq_weighted_sum_losses = sum_losses * num_losses(returns_arr, 0)
    return abs(freq_weighted_sum_losses / freq_weighted_sum_wins)


def sortino_ratio(returns_arr: np.ndarray, threshold: float) -> float:
    """
        Threshold-adjusted average returns per unit of downside risk assumed


        Parameters
        ----------
        returns_arr : array like
            Array with absolute returns
        threshold : float
            Cut-off to determine classification as upside/downside

        Returns
        -------
        sortino_ratio : float
    """
    num_dims: int = returns_arr.ndim
    assert num_dims == 1, "Require 1D array received {}".format(num_dims)
    # noinspection PyTypeChecker
    return (np.mean(returns_arr) - threshold) / downside_risk(returns_arr,
                                                              threshold)


def upside_potential_ratio(returns_arr: np.ndarray, threshold: float) -> float:
    """
        Average upside gains per unit downside risk assumed

        Performance is similar to Sortino ratio

        Parameters
        ----------
        returns_arr : array like
            Array with absolute returns
        threshold : float
            Cut-off to determine classification as upside/downside

        Returns
        -------
        upside_potential_ratio : float
    """
    return upside_potential(returns_arr, threshold) / downside_risk(returns_arr,
                                                                    threshold)


def volatility_skewness(returns_arr: np.ndarray, threshold: float) -> float:
    """
        A similar measure to Omega but using the second partial moment


        Parameters
        ----------
        returns_arr : array like
            Array with absolute returns
        threshold : float
            Cut-off to determine classification as upside/downside

        Returns
        -------
        volatility_skewness : float
    """
    upside_variance = upside_risk(returns_arr, threshold) ** 2
    downside_variance = downside_risk(returns_arr, threshold) ** 2
    return upside_variance / downside_variance


def prospect_ratio(returns_arr: np.ndarray, threshold: float,
                   penalty_factor: float) -> float:
    """
    Sharpe type ratio that penalises losses more than it rewards gains.

    Prospect theory suggests that people have a tendency to
    feel loss more than gain. By weighting the average_losses by a penalty
    factor you can look at algorithm performance from different points of the
    risk-seeking / risk-averse spectrum

    Parameters
    -----------
    returns_arr : array like
            Array with absolute returns
    threshold : float
            Cut-off to determine classification as upside/downside
    penalty_factor: float
            A penalty parameter is set applied to
            the standard sharpe ratio to adjust for prospect theory


    Returns
    -------
        prospect_ratio : float
    """
    average_gains: float = partial_statistic(returns_arr, np.mean, False, 0)
    average_losses: float = partial_statistic(returns_arr, np.mean, True, 0)
    prospect_weighted_avg_losses: float = average_losses * penalty_factor
    p_ratio: float = average_gains + prospect_weighted_avg_losses - threshold
    p_ratio /= downside_risk(returns_arr, threshold)
    return p_ratio


def autocorrelation_test(returns: pd.Series, sig_level: float = 0.05) -> typing.Union[tuple, bool]:
    """
        Test for autocorrelation in returns series using Ljung-Box statistic

        Parameters
        ----------
        returns : pd.Series
            An asset's returns
        sig_level : float
            Significance level for the hypothesis test. Default = 0.05

        Returns
        -------
        autocorrelation_test : tuple
            A tuple (True, np.ndarray of indices with autocorrelation) if there is autocorrelation
            A boolean False otherwise
        """
    result: tuple = acorr_ljungbox(returns, lags=len(returns) - 1)
    p_value: np.ndarray = result[1]
    autocorrelation: np.ndarray = p_value < sig_level
    autocorrelation_indices: np.ndarray = np.where(autocorrelation == True)[0]
    if len(autocorrelation_indices) > 0:
        return True, autocorrelation_indices
    else:
        return False


def stationarity_test(returns: pd.Series, sig_level: float = 0.05) -> bool:
    """
        Test for non-stationarity in returns series using Augmented Dickey-Fuller test

        Parameters
        ----------
        returns : pd.Series
            An asset's returns
        sig_level : float
            Significance level for the hypothesis test. Default = 0.05

        Returns
        -------
        stationarity_test : bool
            True if returns series is stationary
            False otherwise
        """
    result = adfuller(returns)
    # noinspection PyUnresolvedReferences
    p_value = result[1]
    return p_value < sig_level


def difference(returns: pd.Series, interval: int = 1) -> pd.Series:
    """
        Differencing to transform a non-stationary series into a stationary one

        Parameters
        ----------
        returns : pd.Series
            An asset's returns
        interval : int
            Regular differencing if interval not specified. Default = 1
            Seasonal differencing if interval > 1 is specified

        Returns
        -------
        difference : pd.Series
            Differenced series
        """
    returns: pd.Series = returns.copy()
    return returns - returns.shift(interval)


def make_stationary(returns: pd.Series, interval: int = 1,
                    sig_level: float = 0.05) -> tuple:
    """
        Make a non-stationary returns series stationary

        Parameters
        ----------
        returns : pd.Series
            An asset's returns
        interval : int
            Regular differencing if interval not specified. Default = 1
            Seasonal differencing if interval > 1 is specified
        sig_level : float
            Significance level for the hypothesis test. Default = 0.05

        Returns
        -------
        d_and_new_returns : tuple
            A tuple (d, returns) where d is the number of times differenced
            and returns is the stationary returns series after differencing.
            This d is also the same as the d parameter in ARIMA(p, d, q).
        """
    returns: pd.Series = returns.copy()
    d: int = 0
    stationary: bool = False
    while not stationary:
        returns = difference(returns, interval)
        d += 1
        stationary = stationarity_test(returns, sig_level)
    return d, returns


def getPreviousTradingDate():
    tradedOn = dt.date.today()

    while True:
        try:
            tradedOn -= dt.timedelta(days=1)
        except OverflowError:
            return None

        if tradedOn.weekday() not in [5, 6]:
            return tradedOn


def date_to_datetime(d: dt.date):
    return dt.datetime(d.year, d.month, d.day)


MaxDrawdown = collections.namedtuple('max_drawdown_info',
                                     ['max_dd', 'peak_timestamp', 'valley_timestamp',
                                      'recovery_timestamp', 'recovery_time_from_peak',
                                      'recovery_time_from_valley'])


def pnl_absolute_drawdown(daily_net_pnl: pd.Series) -> pd.Series:
    """
        Gets the drawdown series of SignalReturns object

        Parameters
        ----------
        daily_net_pnl: pd.Series
            Daily net pnl

        Returns
        -------
        drawdown_series : pd.Series
        """
    return get_drawdown_from_peak(daily_net_pnl)


def get_cumulative_returns(returns: pd.Series) -> pd.Series:
    """
        Gets the cumulative_pnl from returns series

        Parameters
        ----------
        returns : pd.Series
            Pnl in series

        Returns
        -------
        cumulative_returns : pd.Series
        """
    cumulative_returns: pd.Series = returns.cumsum()
    return cumulative_returns


def get_peak_valley(returns: pd.Series) -> pd.Series:
    """
        Gets the peaks and valleys from returns series

        Parameters
        ----------
        returns : pd.Series
            Pnl in series

        Returns
        -------
        peak_valley_series : pd.Series
            1 for peak, -1 for valley, 0 otherwise
        """
    cumulative_returns: pd.Series = get_cumulative_returns(returns)
    cumulative_returns_center: pd.Series = cumulative_returns[1:-1]
    cumulative_returns_right: pd.Series = cumulative_returns.shift(-1)[1:-1]
    cumulative_returns_left: pd.Series = cumulative_returns.shift()[1:-1]
    minus_right: np.ndarray = np.array(
        cumulative_returns_center - cumulative_returns_right)
    minus_left: np.ndarray = np.array(
        cumulative_returns_center - cumulative_returns_left)
    # 1 for peak, -1 for valley, 0 otherwise
    peak_valley_list: list = []
    for i in range(len(minus_left)):
        if minus_left[i] * minus_right[i] > 0:
            if minus_left[i] < 0:
                peak_valley_list.append(-1)
            else:
                peak_valley_list.append(1)
        else:
            peak_valley_list.append(0)
    # If first non-zero is -1 (valley), remove it
    first_nonzero: int = list(filter(lambda x: x != 0, peak_valley_list))[0]
    if first_nonzero == -1:
        peak_valley_list[peak_valley_list.index(first_nonzero)] = 0

    # Add first and last which was previously removed
    peak_valley_list = [0] + peak_valley_list + [0]
    return pd.Series(peak_valley_list, index=cumulative_returns.index)


def get_drawdown_series(returns: pd.Series) -> pd.Series:
    """
       Gets the drawdown series in absolute terms from returns series

       Parameters
       ----------
       returns : pd.Series
           Pnl in series

       Returns
       -------
       drawdowns : pd.Series
       """
    cumulative_returns: pd.Series = get_cumulative_returns(returns)
    peak_valley_series: pd.Series = get_peak_valley(returns)
    peak_valley_series = peak_valley_series[peak_valley_series != 0]
    drawdowns: pd.Series = pd.Series([0.0] * len(cumulative_returns),
                                     index=cumulative_returns.index)

    for i in range(0, len(peak_valley_series) - 1, 2):
        drawdown: float = \
            cumulative_returns[peak_valley_series.index[i]] - \
            cumulative_returns[peak_valley_series.index[i + 1]]
        drawdowns[peak_valley_series.index[i + 1]] = drawdown
    return drawdowns


def get_drawdown_from_peak(returns: pd.Series) -> pd.Series:
    """
        Gets the drawdown from peak series in absolute terms from returns series

        Parameters
        ----------
        returns : pd.Series
            Pnl in series

        Returns
        -------
        drawdown_from_peak : pd.Series
        """
    cumulative_returns: pd.Series = get_cumulative_returns(returns)
    rolling_maximum: pd.Series = np.maximum.accumulate(cumulative_returns)
    # cumulative_returns.cummax()
    return rolling_maximum - cumulative_returns


def maximum_drawdown(returns: pd.Series) -> typing.NamedTuple:
    """
        Gets a tuple of information regarding the maximum drawdown from returns series

        Parameters
        ----------
        returns : pd.Series
            Pnl in series

        Returns
        -------
        max_drawdown_info : NamedTuple
            Tuple will consist of (max_dd, peak_timestamp, valley_timestamp, recovery_timestamp,
            recovery_time_from_peak, recovery_time_from_valley)
        """
    drawdowns: pd.Series = get_drawdown_from_peak(returns)
    max_dd: float = np.max(drawdowns)
    recovery_time_info: typing.Tuple = recovery_time(drawdowns)
    max_drawdown_info = MaxDrawdown(max_dd, recovery_time_info[0],
                                    recovery_time_info[1],
                                    recovery_time_info[2],
                                    recovery_time_info[3],
                                    recovery_time_info[4])

    return max_drawdown_info


def time_to_recovery(returns: pd.Series,
                     ref_date: pd.Timestamp) -> pd.Timedelta:
    """
        Gets a tuple of information regarding the maximum drawdown from returns series

        Parameters
        ----------
        returns : pd.Series
            Pnl in series
        ref_date : pd.Timestamp
            Reference date

        Returns
        -------
        days_to_recovery : pd.Timedelta
            Time left to recovery
        """
    max_drawdown_info: typing.NamedTuple = maximum_drawdown(returns)
    assert ref_date < max_drawdown_info.recovery_timestamp
    return max_drawdown_info.recovery_timestamp - ref_date


def recovery_time(drawdowns: pd.Series) -> typing.Tuple:
    """
        Gets the recovery time (or drawdown duration) from the peak and valley of maximum drawdown

        Parameters
        ----------
        drawdowns : pd.Series
            Pnl in series

        Returns
        -------
        recovery_time_info : Tuple
            Tuple will consist of (peak_timestamp, valley_timestamp, recovery_timestamp,
            recovery_time_from_peak, recovery_time_from_valley)
        """
    valley_timestamp: pd.Timestamp = drawdowns.index[
        np.where(drawdowns == drawdowns.max())[0][0]]
    peak_timestamp: pd.Timestamp = \
        drawdowns[:valley_timestamp].index[
            np.where(drawdowns[:valley_timestamp] == 0)[0][-1]]

    recovery_timestamp = np.inf
    if len(np.where(drawdowns[valley_timestamp:] == 0)[0]) > 0:
        recovery_timestamp: pd.Timestamp = drawdowns[valley_timestamp:].index[
            np.where(drawdowns[valley_timestamp:] == 0)[0][0]]

    recovery_time_valley = recovery_time_peak = np.inf
    if recovery_timestamp != np.inf:
        recovery_time_valley: pd.Timedelta = recovery_timestamp - valley_timestamp
        recovery_time_peak: pd.Timedelta = recovery_timestamp - peak_timestamp

    return peak_timestamp, valley_timestamp, recovery_timestamp, recovery_time_peak, recovery_time_valley


def average_annual_max_drawdown(returns: pd.Series) -> float:
    """
        Gets the average annual maximum drawdown from returns series

        Parameters
        ----------
        returns : pd.Series
            Pnl in series

        Returns
        -------
        average_annual_max_drawdown : float
        """
    drawdowns = get_drawdown_from_peak(returns)
    curr_timestamp: pd.Timestamp = returns.index[0]
    annual_max_dd: list = []
    while curr_timestamp < returns.index[-1]:
        end_timestamp: pd.Timestamp = curr_timestamp + pd.Timedelta(weeks=52)
        annual_max_dd.append(np.max(drawdowns[curr_timestamp: end_timestamp]))
        curr_timestamp = end_timestamp
    return np.mean(annual_max_dd)


def average_drawdown(returns: pd.Series) -> float:
    """
        Gets the average drawdown of returns series

        Parameters
        ----------
        returns : pd.Series
            Pnl in series

        Returns
        -------
        average_drawdown : float
        """
    drawdowns: pd.Series = get_drawdown_series(returns)
    # noinspection PyTypeChecker
    return np.mean(drawdowns)


def continuous_drawdown_deviation(returns: pd.Series) -> float:
    """
        Gets the continuous standard deviation of the drawdowns

        Parameters
        ----------
        returns : pd.Series
            Pnl in series

        Returns
        -------
        drawdown_deviation : float
        """
    drawdowns: pd.Series = get_drawdown_series(returns)
    return np.std(drawdowns)


def ulcer_index(returns: pd.Series) -> float:
    """
         Similar to drawdown deviation with the exception that the impact of time
         “under water” is combined with the depth of drawdown by selecting the
         negative return for each period below the previous peak or high water mark.

        Parameters
        ----------
        returns : pd.Series
            Pnl in series

        Returns
        -------
        ulcer_index : float
        """
    drawdowns = get_drawdown_from_peak(returns)
    return np.sqrt(np.mean(
        np.square(100 * (drawdowns - np.max(drawdowns)) / np.max(drawdowns))))


def pain_index(returns: pd.Series) -> float:
    """
        Mean value of the absolute drawdowns over the entire analysis period

        Parameters
        ----------
        returns : pd.Series
            Pnl in series

        Returns
        -------
        pain_index : float
        """
    drawdowns = get_drawdown_from_peak(returns)
    return np.mean(np.abs(drawdowns))


def calmar_ratio(returns: pd.Series, base_capital: float,
                 start_date: pd.Timestamp,
                 period: float = 3.0, risk_free_rate: float = 0.0) -> float:
    # todo - set start_date default as today datetime
    """
        A Sharpe type measure that uses maximum drawdown rather than standard deviation
        to reflect the investor’s risk. Calmar is an acronym of California Managed Annual
        Reports and is always measured over 36 months.

        Parameters
        ----------
        returns: pd.Series
            Pnl series
        base_capital : float
            Base capital of investor
        start_date : pd.Timestamp
            Date to start calculation from
        period : float
            Number of years from start_date, default set to 3 years
        risk_free_rate : float
            Risk free rate in absolute terms

        Returns
        -------
        calmar_ratio : float
        """
    returns: pd.Series = returns.copy(deep=True)
    max_dd: float = np.max(get_drawdown_from_peak(returns))
    end_date: pd.Timestamp = start_date + pd.Timedelta(weeks=52 * period)
    # Get 36 months worth of returns from start_date by default
    assert returns.index[-1] >= end_date, \
        "Expected 36 months after start_date, got {} days".format(
            (returns.index[-1] - start_date).days)
    returns = returns[start_date: end_date]
    return (((
                 returns / base_capital).mean() - risk_free_rate) * base_capital) / max_dd


def mar_ratio(returns: pd.Series, base_capital: float,
              risk_free_rate: float = 0.0) -> float:
    """
        Calmar ratio when calculated from inception (ignoring 36 months constraint)

        See Also
        --------
        drawdown.calmar_ratio
        """
    period: float = (returns.index[-1] - returns.index[0]).days / 365
    return calmar_ratio(returns, base_capital, returns.index[0], period,
                        risk_free_rate)


def sterling_ratio(returns: pd.Series, base_capital: float,
                   risk_free_rate: float = 0.0) -> float:
    """
        Sterling ratio replaces maximum drawdown in the calmar_ratio with the average drawdown
        over the period of analysis.

        Parameters
        ----------
        returns: pd.Series
            Pnl series
        base_capital : float
            Base capital of investor
        risk_free_rate : float
            Risk free rate in absolute terms

        Returns
        -------
        sterling_ratio : float
        """
    return (((
                 returns / base_capital).mean() - risk_free_rate) * base_capital) / average_drawdown(
        returns)


def sterling_calmar_ratio(returns: pd.Series, base_capital: float,
                          risk_free_rate: float = 0.0) -> float:
    """
       A combination of both Sterling and Calmar concepts.

       Parameters
       ----------
       returns: pd.Series
           Pnl series
       base_capital : float
           Base capital of investor
       risk_free_rate : float
           Risk free rate in absolute terms

       Returns
       -------
       sterling_calmar_ratio : float
       """
    return (((
                 returns / base_capital).mean() - risk_free_rate) * base_capital) / average_annual_max_drawdown(
        returns)


def burke_ratio(returns: pd.Series, base_capital: float,
                risk_free_rate: float = 0.0) -> float:
    """
       Using drawdown_deviation in order to penalise major drawdowns as opposed to many mild ones

       Parameters
       ----------
       returns: pd.Series
           Pnl series
       base_capital : float
           Base capital of investor
       risk_free_rate : float
           Risk free rate in absolute terms

       Returns
       -------
       burke_ratio : float
       """
    return (((
                 returns / base_capital).mean() - risk_free_rate) * base_capital) / continuous_drawdown_deviation(
        returns)


def martin_ratio(returns: pd.Series, base_capital: float,
                 risk_free_rate: float = 0.0) -> float:
    """
       Using ulcer_index in order to penalise major drawdowns as opposed to many mild ones

       Parameters
       ----------
       returns: pd.Series
           Pnl series
       base_capital : float
           Base capital of investor
       risk_free_rate : float
           Risk free rate in absolute terms

       Returns
       -------
       martin_ratio : float
       """
    return (((
                 returns / base_capital).mean() - risk_free_rate) * base_capital) / ulcer_index(
        returns)


def pain_ratio(returns: pd.Series, base_capital: float,
               risk_free_rate: float = 0.0) -> float:
    """
       Using pain_index in order to penalise major drawdowns as opposed to many mild ones

       Parameters
       ----------
       returns: pd.Series
           Pnl series
       base_capital : float
           Base capital of investor
       risk_free_rate : float
           Risk free rate in absolute terms

       Returns
       -------
       pain_ratio : float
       """
    return (((
                 returns / base_capital).mean() - risk_free_rate) * base_capital) / pain_index(
        returns)


def lake_ratio(returns: pd.Series) -> float:
    """
       An alternative drawdown statistic combining drawdown magnitude with drawdown duration.
       The Lake ratio is constructed from the ratio of the volume in the valleys (or lakes)
       of the performance track record with the total volume under the cumulative return.
       To some degree the Lake ratio compensates for high early peaks in performance by taking
       into account the duration and timing of the peaks.

       Parameters
       ----------
       returns: pd.Series
           Pnl series

       Returns
       -------
       lake_ratio : float
       """
    cumulative_returns: pd.Series = get_cumulative_returns(returns)

    # Resample cumulative_returns to daily if frequency is longer than daily and interpolate missing values
    daily_cum_returns: pd.Series = cumulative_returns.resample('D').interpolate(
        'linear')

    # Shift x-axis down to lowest cumulative_return such that area is all positive
    if np.min(daily_cum_returns) < 0:
        daily_cum_returns += np.min(daily_cum_returns) * -1
    else:
        daily_cum_returns += np.min(daily_cum_returns)

    peak_valley_series: pd.Series = get_peak_valley(returns)
    assert -1 in np.array(peak_valley_series), "Expected at least 1 lake, got 0"
    peaks: pd.Series = peak_valley_series[peak_valley_series > 0]
    lake_areas_from_left: pd.DataFrame = pd.DataFrame([],
                                                      index=daily_cum_returns.index,
                                                      columns=['end_date',
                                                               'area'])
    lake_areas_from_right: pd.DataFrame = pd.DataFrame([],
                                                       index=daily_cum_returns.index,
                                                       columns=['end_date',
                                                                'area'])

    # Get all valleys by looking right
    curr_timestamp: pd.Timestamp = peaks.index[0]
    for i in range(len(peaks)):
        start_timestamp: pd.Timestamp = peaks.index[i]
        if start_timestamp < curr_timestamp:
            continue
        curr_cum_return: float = daily_cum_returns[start_timestamp]
        cum_return_above_after: pd.Series = daily_cum_returns[start_timestamp:][
            daily_cum_returns >= curr_cum_return]
        if len(cum_return_above_after) == 1:
            continue
        recovery_timestamp: pd.Timestamp = cum_return_above_after.index[1]
        lake_areas_from_left.loc[start_timestamp] = \
            [recovery_timestamp,
             curr_cum_return * (recovery_timestamp - start_timestamp).days \
             - np.trapz(daily_cum_returns[start_timestamp: recovery_timestamp],
                        dx=1)]
        curr_timestamp = recovery_timestamp

    # Get all valleys by looking left
    curr_timestamp: pd.Timestamp = peaks.index[0]
    for j in range(len(peaks)):
        start_timestamp: pd.Timestamp = peaks.index[j]
        if start_timestamp < curr_timestamp:
            continue
        curr_cum_return: float = daily_cum_returns[start_timestamp]
        cum_return_above_before: pd.Series = \
            daily_cum_returns[:start_timestamp][
                daily_cum_returns >= curr_cum_return]
        if len(cum_return_above_before) == 1:
            continue
        recovery_timestamp: pd.Timestamp = cum_return_above_before.index[-2]
        lake_areas_from_right.loc[recovery_timestamp] = \
            [start_timestamp,
             curr_cum_return * (start_timestamp - recovery_timestamp).days \
             - np.trapz(daily_cum_returns[recovery_timestamp: start_timestamp],
                        dx=1)]
        curr_timestamp = start_timestamp

    # Get rows of lake_areas_from_left/right df that has area
    lake_areas_from_left = lake_areas_from_left.loc[
        lake_areas_from_left['area'] > 0]
    lake_areas_from_right = lake_areas_from_right.loc[
        lake_areas_from_right['area'] > 0]

    lakes_df: pd.DataFrame = pd.DataFrame([], index=daily_cum_returns.index,
                                          columns=['end_date', 'area'])
    for idx_left, row_left in lake_areas_from_left.iterrows():
        for idx_right, row_right in lake_areas_from_right.iterrows():
            # if there is overlap in any way
            if (idx_left > idx_right and row_left['end_date'] < row_right[
                'end_date']) or \
                (idx_left < idx_right and row_left['end_date'] > row_right[
                    'end_date']):
                if row_left['area'] < row_right['area']:
                    lakes_df.loc[idx_right] = row_right
                else:
                    lakes_df.loc[idx_left] = row_left
            else:
                lakes_df.loc[idx_left] = row_left

    lake_area: float = np.sum(lakes_df[lakes_df['area'] > 0]['area'])
    return lake_area / np.trapz(daily_cum_returns, dx=1)


def peak_ratio(returns: pd.Series) -> float:
    """
       Inverse of lake_ratio

       Parameters
       ----------
       returns: pd.Series
           Pnl series

       Returns
       -------
       peak_ratio : float
       """
    return 1 / lake_ratio(returns)


def to_pct_returns(returns: pd.Series, base_capital: float) -> pd.Series:
    """
        Convert absolute returns to percentage terms

        Parameters
        ----------
        returns : pd.Series
            Any returns
        base_capital : float
            Base capital

        Returns
        -------
        to_pct_returns : pd.Series
        """
    returns = returns.copy(deep=True)
    returns = 100 * (returns / base_capital)
    return returns


def regression_alpha(strat_returns: pd.Series, benchmark_returns: pd.Series) -> float:
    """
        Regression alpha is the intercept of the regression equation with the vertical axis

        Parameters
        ----------
        strat_returns : pd.Series
            Strategy returns
        benchmark_returns : pd.Series
            Benchmark returns

        Returns
        -------
        regression_alpha : float
        """
    strat_mean: float = np.mean(strat_returns)
    beta: float = regression_beta(strat_returns, benchmark_returns)
    benchmark_mean: float = np.mean(benchmark_returns)
    return strat_mean - beta * benchmark_mean


def regression_beta(strat_returns: pd.Series, benchmark_returns: pd.Series) -> float:
    """
        Regression beta is the slope of the regression equation

        Parameters
        ----------
        strat_returns : pd.Series
            Strategy returns
        benchmark_returns : pd.Series
            Benchmark returns

        Returns
        -------
        regression_beta : float
        """
    covariance: float = np.cov(strat_returns, benchmark_returns, ddof=0)[0][1]
    benchmark_var: float = np.var(benchmark_returns)
    return covariance / benchmark_var


def regression_epsilon(strat_returns: pd.Series, benchmark_returns: pd.Series) -> pd.Series:
    """
        Regression epsilon is the error term measuring the vertical distance between
        the return predicted by the equation and the real result

        Parameters
        ----------
        strat_returns : pd.Series
            Strategy returns
        benchmark_returns : pd.Series
            Benchmark returns

        Returns
        -------
        regression_epsilon : float
        """
    alpha: float = regression_alpha(strat_returns, benchmark_returns)
    beta: float = regression_beta(strat_returns, benchmark_returns)
    return strat_returns - alpha - beta * benchmark_returns


def capm_beta(strat_returns: pd.Series, benchmark_returns: pd.Series,
              risk_free: pd.Series = None) -> float:
    """
        The beta (systematic risk/ volatility) in CAPM model; derived by comparing
        the excess return of the strat against the risk free rate with the
        excess return of benchmark against the same risk free rate

        Parameters
        ----------
        strat_returns : pd.Series
            Strategy returns
        benchmark_returns : pd.Series
            Benchmark returns
        risk_free : pd.Series
            Risk free rates

        Returns
        -------
        capm_beta : float
        """
    risk_free_mean: float = np.mean(risk_free)
    strat_computation: pd.Series = strat_returns - risk_free - np.mean(strat_returns) + risk_free_mean
    benchmark_computation: pd.Series = benchmark_returns - risk_free - np.mean(benchmark_returns) + risk_free_mean
    return np.dot(strat_computation, benchmark_computation) / np.sum(np.square(benchmark_computation))


def jensen_alpha(strat_returns: pd.Series, benchmark_returns: pd.Series,
                 risk_free: pd.Series = None) -> float:
    """
        Jensen's alpha is the intercept of the regression equation in the CAPM
        model and is the excess return adjusted for systematic risk

        Parameters
        ----------
        strat_returns : pd.Series
            Strategy returns
        benchmark_returns : pd.Series
            Benchmark returns
        risk_free : pd.Series
            Risk free rates

        Returns
        -------
        jensen_alpha : float
        """
    strat_mean: float = np.mean(strat_returns)
    benchmark_mean: float = np.mean(benchmark_returns)
    risk_free_mean: float = np.mean(risk_free)
    beta: float = capm_beta(strat_returns, benchmark_returns, risk_free)
    return strat_mean - risk_free_mean - beta * (benchmark_mean - risk_free_mean)


def annualised_reg_alpha(strat_returns: pd.Series, benchmark_returns: pd.Series,
                         base_capital: float, period: int) -> float:
    """
        Annualised regression alpha

        Parameters
        ----------
        strat_returns : pd.Series
            Strategy returns
        benchmark_returns : pd.Series
            Benchmark returns
        base_capital : float
            Base capital
        period : int
            2 - semiannual, 4 - quarterly, 12 - monthly, 52 - weekly, 252 - daily
        risk_free : pd.Series
            Risk free rates

        Returns
        -------
        annualised_reg_alpha : float

        See Also
        --------
        regression.regression_alpha
        """
    strat_pct_returns: pd.Series = to_pct_returns(strat_returns, base_capital)
    benchmark_pct_returns: pd.Series = to_pct_returns(benchmark_returns, base_capital)
    annual_strat_returns: float = (np.prod(strat_pct_returns) ** (period / len(strat_pct_returns))) - 1
    annual_benchmark_returns: float = (np.prod(benchmark_pct_returns) ** (period / len(benchmark_pct_returns))) - 1
    return annual_strat_returns - regression_beta(strat_pct_returns, benchmark_returns) * annual_benchmark_returns


def annualised_jensen_alpha(strat_returns: pd.Series, benchmark_returns: pd.Series,
                            base_capital: float, period: int, risk_free: pd.Series = None) -> float:
    """
        Annualised Jensen's alpha

        Parameters
        ----------
        strat_returns : pd.Series
            Strategy returns
        benchmark_returns : pd.Series
            Benchmark returns
        base_capital : float
            Base capital
        period : int
            2 - semiannual, 4 - quarterly, 12 - monthly, 52 - weekly, 252 - daily
        risk_free : pd.Series
            Risk free rates

        Returns
        -------
        annualised_jensen_alpha : float

        See Also
        --------
        regression.jensen_alpha
        """
    strat_pct_returns: pd.Series = to_pct_returns(strat_returns, base_capital)
    benchmark_pct_returns: pd.Series = to_pct_returns(benchmark_returns, base_capital)
    annual_strat_returns: float = (np.prod(strat_pct_returns) ** (period / len(strat_pct_returns))) - 1
    annual_benchmark_returns: float = (np.prod(benchmark_pct_returns) ** (period / len(benchmark_pct_returns))) - 1
    annual_risk_free: float = (np.prod(risk_free) ** (period / len(risk_free))) - 1
    return annual_strat_returns - annual_risk_free - capm_beta(strat_returns, benchmark_returns, risk_free) \
           * (annual_benchmark_returns - annual_risk_free)


def bull_beta(strat_returns: pd.Series, benchmark_returns: pd.Series) -> float:
    """
        Bull beta is calculated same way as regression beta but with only positive
        benchmark returns

        Parameters
        ----------
        strat_returns : pd.Series
            Strategy returns
        benchmark_returns : pd.Series
            Benchmark returns

        Returns
        -------
        bull_beta : float
        """
    positive_benchmark_returns: pd.Series = benchmark_returns[benchmark_returns > 0]
    strat_returns = strat_returns.copy(deep=True)
    strat_returns = strat_returns[benchmark_returns > 0]
    return regression_beta(strat_returns, positive_benchmark_returns)


def bear_beta(strat_returns: pd.Series, benchmark_returns: pd.Series) -> float:
    """
        Bear beta is calculated same way as regression beta but with only negative
        benchmark returns

        Parameters
        ----------
        strat_returns : pd.Series
            Strategy returns
        benchmark_returns : pd.Series
            Benchmark returns

        Returns
        -------
        bear_beta : float
        """
    negative_benchmark_returns: pd.Series = benchmark_returns[benchmark_returns < 0]
    strat_returns = strat_returns.copy(deep=True)
    strat_returns = strat_returns[benchmark_returns < 0]
    return regression_beta(strat_returns, negative_benchmark_returns)


def beta_timing_ratio(strat_returns: pd.Series, benchmark_returns: pd.Series) -> float:
    """
        Ratio of bull against bear beta

        Parameters
        ----------
        strat_returns : pd.Series
            Strategy returns
        benchmark_returns : pd.Series
            Benchmark returns

        Returns
        -------
        beta_timing_ratio : float
        """
    return bull_beta(strat_returns, benchmark_returns) / bear_beta(strat_returns, benchmark_returns)


def systematic_risk(strat_returns: pd.Series, benchmark_returns: pd.Series) -> float:
    """
        A better definition of systematic risk compared to CAPM beta. Systematic risk
        here is defined as the product of CAPM beta or regression beta, with benchmark risk.
        We use regression beta for this method.

        Parameters
        ----------
        strat_returns : pd.Series
            Strategy returns
        benchmark_returns : pd.Series
            Benchmark returns

        Returns
        -------
        systematic_risk : float
        """
    return regression_beta(strat_returns, benchmark_returns) * np.std(benchmark_returns)


def specific_risk(strat_returns: pd.Series, benchmark_returns: pd.Series) -> float:
    """
        Residual or specific risk is not attributed to general market movements.
        It is represented by the standard deviation of the error term in the
        regression equation.

        Parameters
        ----------
        strat_returns : pd.Series
            Strategy returns
        benchmark_returns : pd.Series
            Benchmark returns

        Returns
        -------
        specific_risk : float
        """
    return np.std(regression_epsilon(strat_returns, benchmark_returns))


def total_risk(strat_returns: pd.Series, benchmark_returns: pd.Series) -> float:
    """
        A combination of systematic and specific risks

        Parameters
        ----------
        strat_returns : pd.Series
            Strategy returns
        benchmark_returns : pd.Series
            Benchmark returns

        Returns
        -------
        total_risk : float
        """
    return np.sqrt(np.square(systematic_risk(strat_returns, benchmark_returns))
                   + np.square(specific_risk(strat_returns, benchmark_returns)))


def correlation(strat_returns: pd.Series, benchmark_returns: pd.Series) -> float:
    """
        Correlation between strat returns and benchmark returns

        Parameters
        ----------
        strat_returns : pd.Series
            Strategy returns
        benchmark_returns : pd.Series
            Benchmark returns

        Returns
        -------
        correlation : float
        """
    return systematic_risk(strat_returns, benchmark_returns) / total_risk(strat_returns, benchmark_returns)


def coeff_of_determination(strat_returns: pd.Series, benchmark_returns: pd.Series) -> float:
    """
        R^2 or coefficient of determination is the proportion of variance in strat returns that
        is related to the variance of benchmark returns; it is a measure of portfolio diversification.

        Closer R^2 is to 1, the more portfolio variance is explained by benchmark variance.
        A low R^2 would indicate that returns are more scattered and would indicate less reliable
        line of best fit leading to unstable alphas and betas. Therefore a portfolio has a low R^2,
        say much less than 0.7, then any alphas and betas and their derivative statistics should
        probably be ignored.

        Parameters
        ----------
        strat_returns : pd.Series
            Strategy returns
        benchmark_returns : pd.Series
            Benchmark returns

        Returns
        -------
        coeff_of_determination : float
        """
    return np.square(correlation(strat_returns, benchmark_returns))


def fama_beta(strat_returns: pd.Series, benchmark_returns: pd.Series) -> float:
    """
        Fama beta is the effective beta required so that the systematic risk
        is equivalent to the total risk

        Note the Fama beta will always be greater than or equal to the portfolio
        beta since total risk is greater than or equal to the systematic risk
        of the portfolio.

        Parameters
        ----------
        strat_returns : pd.Series
            Strategy returns
        benchmark_returns : pd.Series
            Benchmark returns

        Returns
        -------
        fama_beta : float
        """
    return total_risk(strat_returns, benchmark_returns) / np.std(benchmark_returns)


def diversification(strat_returns: pd.Series, benchmark_returns: pd.Series,
                    risk_free: pd.Series = None) -> float:
    """
        Diversiﬁcation is the return required to justify moving away from the benchmark
        and taking on specific risk.It calculates the return that would have been achieved
        simply by taking the same amount of systematic risk as the total risk.

        If the benchmark return is greater than the risk free rate the diversiﬁcation
        required will be positive.

        Parameters
        ----------
        strat_returns : pd.Series
            Strategy returns
        benchmark_returns : pd.Series
            Benchmark returns
        risk_free : pd.Series
            Risk free rates

        Returns
        -------
        diversification : float
        """
    return (fama_beta(strat_returns, benchmark_returns) - capm_beta(strat_returns, benchmark_returns, risk_free)) \
           * (np.mean(benchmark_returns) - np.mean(risk_free))


def net_selectivity(strat_returns: pd.Series, benchmark_returns: pd.Series,
                    risk_free: pd.Series = None) -> float:
    """
        Net selectivity is the remaining selectivity after deducting the amount
        of return required to justify not being fully diversiﬁed.

        If net selectivity is negative the portfolio manager has not justiﬁed
        the loss of diversiﬁcation.

        Parameters
        ----------
        strat_returns : pd.Series
            Strategy returns
        benchmark_returns : pd.Series
            Benchmark returns
        risk_free : pd.Series
            Risk free rates

        Returns
        -------
        net_selectivity : float
        """
    return jensen_alpha(strat_returns, benchmark_returns, risk_free) \
           - diversification(strat_returns, benchmark_returns, risk_free)


def k_ratio(strat_returns: pd.Series, benchmark_returns: pd.Series) -> float:
    """
        K ratio is a reward to risk measure.
        The “reward” is the slope of the cumulative return – the greater the upward slope the better.
        The risk is the deviation from the resultant trend line measured by standard deviation, lower
        standard deviation indicating greater consistency in the delivery of cumulative return.

        Parameters
        ----------
        strat_returns : pd.Series
            Strategy returns
        benchmark_returns : pd.Series
            Benchmark returns

        Returns
        -------
        K_ratio : float
        """
    strat_cum_returns: pd.Series = strat_returns.cumsum()
    period: list = list(range(1, len(strat_returns) + 1))
    return regression_beta(strat_cum_returns, period) / np.std(strat_cum_returns)


def modified_k_ratio(strat_returns: pd.Series, benchmark_returns: pd.Series) -> float:
    """
        Modiﬁed the K ratio to standardise over different time periods

        See Also
        --------
        regression.k_ratio
        """
    return k_ratio(strat_returns, benchmark_returns) / len(strat_returns)


def treynor_ratio(strat_returns: pd.Series, benchmark_returns: pd.Series,
                  base_capital: float, period: int, risk_free: pd.Series = None) -> float:
    """
        Treynor ratio is a reward to volatility ratio.
        It is similar to, but predates, the Sharpe ratio by one year

        Parameters
        ----------
        strat_returns : pd.Series
            Strategy returns
        benchmark_returns : pd.Series
            Benchmark returns
        base_capital : float
            Base capital
        period : int
            2 - semiannual, 4 - quarterly, 12 - monthly, 52 - weekly, 252 - daily
        risk_free : pd.Series
            Risk free rates

        Returns
        -------
        treynor_ratio : float
        """
    strat_pct_returns: pd.Series = to_pct_returns(strat_returns, base_capital)
    annual_strat_returns: float = (np.prod(strat_pct_returns) ** (period / len(strat_pct_returns))) - 1
    annual_risk_free: float = (np.prod(risk_free) ** (period / len(risk_free))) - 1
    return (annual_strat_returns - annual_risk_free) / capm_beta(strat_returns, benchmark_returns, risk_free)


def modified_treynor_ratio(strat_returns: pd.Series, benchmark_returns: pd.Series,
                           base_capital: float, period: int, risk_free: pd.Series = None) -> float:
    """
        An alternative form of Treynor ratio which uses systematic risk in the denominator,
        which is more consistent with the Sharpe ratio

        Parameters
        ----------
        strat_returns : pd.Series
            Strategy returns
        benchmark_returns : pd.Series
            Benchmark returns
        base_capital : float
            Base capital
        period : int
            2 - semiannual, 4 - quarterly, 12 - monthly, 52 - weekly, 252 - daily
        risk_free : pd.Series
            Risk free rates

        Returns
        -------
        modified_treynor_ratio : float
        """
    strat_pct_returns: pd.Series = to_pct_returns(strat_returns, base_capital)
    annual_strat_returns: float = (np.prod(strat_pct_returns) ** (period / len(strat_pct_returns))) - 1
    annual_risk_free: float = (np.prod(risk_free) ** (period / len(risk_free))) - 1
    return (annual_strat_returns - annual_risk_free) / systematic_risk(strat_returns, benchmark_returns)


def appraisal_ratio(strat_returns: pd.Series, benchmark_returns: pd.Series,
                    base_capital: float, period: int, risk_free: pd.Series = None) -> float:
    """
        Appraisal ratio measures the systematic risk-adjusted reward for each unit of specific risk taken.
        This measure is sometimes erroneously described as the information ratio.

        Parameters
        ----------
        strat_returns : pd.Series
            Strategy returns
        benchmark_returns : pd.Series
            Benchmark returns
        base_capital : float
            Base capital
        period : int
            2 - semiannual, 4 - quarterly, 12 - monthly, 52 - weekly, 252 - daily
        risk_free : pd.Series
            Risk free rates

        Returns
        -------
        appraisal_ratio : float
        """
    return annualised_jensen_alpha(strat_returns, benchmark_returns, base_capital, period, risk_free) \
           / specific_risk(strat_returns, benchmark_returns)


def modified_jensen(strat_returns: pd.Series, benchmark_returns: pd.Series,
                    base_capital: float, period: int, risk_free: pd.Series = None) -> float:
    """
        Modified Jensen measures the systematic risk-adjusted return per unit of systematic risk

        Parameters
        ----------
        strat_returns : pd.Series
            Strategy returns
        benchmark_returns : pd.Series
            Benchmark returns
        base_capital : float
            Base capital
        period : int
            2 - semiannual, 4 - quarterly, 12 - monthly, 52 - weekly, 252 - daily
        risk_free : pd.Series
            Risk free rates

        Returns
        -------
        modified_jensen : float
        """
    ann_jensen_alpha = annualised_jensen_alpha(strat_returns, benchmark_returns, base_capital, period, risk_free)
    return ann_jensen_alpha / capm_beta(strat_returns, benchmark_returns, risk_free)
