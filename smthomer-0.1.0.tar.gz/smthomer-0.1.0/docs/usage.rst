=====
Usage
=====

To use homer in a project::

    import homer
