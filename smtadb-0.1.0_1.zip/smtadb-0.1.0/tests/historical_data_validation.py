import logging
import pprint

import pandas as pd
import adb.adb as adb
from homer import validation
from babel.tickers import all_tickers
from functools import partial

# create logger
logger = logging.getLogger('historical_data_validation')
logger.setLevel(logging.DEBUG)

# create formatter and add it to the handlers
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# create console handler with a higher log level
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
logger.addHandler(ch)

THRESH_PCNT: float = 2


def validate_ticker_historical_data(ticker, st=None, end=None) -> bool:
    df: pd.DataFrame = adb.read_symbol(ticker, st, end)

    logger.debug(ticker)
    logger.debug("===================================")
    logger.info(df.head())
    logger.debug("===================================")

    logger.debug("Date Gaps Excluding Boundary Dates:")
    date_gaps = validation.check_date_gap(df)
    logger.debug(pprint.pformat(date_gaps))
    logger.debug("===================================")

    logger.debug("High-Low Inversion Dates (Lows >= Highs):")
    high_low_inversions = validation.check_high_low_inversion(df)
    logger.debug(pprint.pformat(high_low_inversions))
    logger.debug("===================================")

    logger.debug("Intraday Spikes")
    intraday_spikes = validation.check_intraday_spike(df, THRESH_PCNT)
    logger.debug(pprint.pformat(intraday_spikes))
    logger.debug("===================================")

    logger.debug("TodayClose-TommOpen Spikes")
    next_day_spikes = validation.check_nextday_spike(df, THRESH_PCNT)
    logger.debug(pprint.pformat(next_day_spikes))
    logger.debug("===================================")

    logger.debug("Validation Complete")
    logger.debug("===================================")

    return len(date_gaps) == 0 and len(high_low_inversions) == 0


def validate_all_tickers(st=None, end=None, use_pool: bool = False):
    fn = partial(validate_ticker_historical_data, st=st, end=end)
    logger.debug(pprint.pformat({t: fn(t) for t in all_tickers()}))


if __name__ == '__main__':
    validate_all_tickers()
